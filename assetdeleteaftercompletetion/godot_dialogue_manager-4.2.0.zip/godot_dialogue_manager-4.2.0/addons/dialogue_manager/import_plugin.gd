@tool
class_name DMImportPlugin extends EditorImportPlugin


signal compiled_resource(resource: DialogueResource)


const COMPILER_VERSION: int = 18


func _init() -> void:
	var current_version: int = DMSettings.get_user_value("compiler_version", -1)
	if current_version != COMPILER_VERSION:
		DMSettings.set_user_value("compiler_version", COMPILER_VERSION)
		DMCache.reimport_all_files()


func _get_importer_name() -> String:
	return "dialogue_manager"


func _get_format_version() -> int:
	return COMPILER_VERSION


func _get_visible_name() -> String:
	return "Dialogue"


func _get_import_order() -> int:
	return -1000


func _get_priority() -> float:
	return 1000.0


func _get_resource_type() -> String:
	return "Resource"


func _get_recognized_extensions() -> PackedStringArray:
	return PackedStringArray(["dialogue"])


func _get_save_extension() -> String:
	return "tres"


func _get_preset_count() -> int:
	return 0


func _get_preset_name(_preset_index: int) -> String:
	return "Unknown"


func _get_import_options(_path: String, _preset_index: int) -> Array:
	# When the options array is empty there is a misleading error on export
	# that actually means nothing so let's just have an invisible option.
	return [{
		name = "defaults",
		default_value = true
	}]


func _get_option_visibility(_path: String, _option_name: StringName, _options: Dictionary) -> bool:
	return false


func _import(source_file: String, save_path: String, _options: Dictionary, _platform_variants: Array[String], _gen_files: Array[String]) -> Error:
	# Get the raw file contents
	if not FileAccess.file_exists(source_file): return ERR_FILE_NOT_FOUND

	var file: FileAccess = FileAccess.open(source_file, FileAccess.READ)
	var raw_text: String = file.get_as_text()

	DMPlugin.instance.cache_file_content_changed.emit(source_file, raw_text)

	# Compile the text
	var result: DMCompilerResult = DMCompiler.compile_string(raw_text, source_file)
	if result.errors.size() > 0:
		printerr("%d errors found in %s" % [result.errors.size(), source_file])
		DMCache.add_errors_to_file(source_file, result.errors)
		return OK

	# Get the current addon version
	var config: ConfigFile = ConfigFile.new()
	config.load("res://addons/dialogue_manager/plugin.cfg")
	var version: String = config.get_value("plugin", "version")

	# Save the results to a resource
	var resource: DialogueResource = DialogueResource.new()
	resource.set_meta("dialogue_manager_version", version)

	resource.using_states = result.using_states
	resource.cues = result.cues
	resource.first_cue = result.first_cue
	resource.character_names = result.character_names
	resource.lines = result.lines

	if DMSettings.get_setting(DMSettings.INCLUDE_RAW_TEXT_IN_DIALOGUE_RESOURCE_META_DATA, false):
		resource.set_meta("raw_text", raw_text)

	# Clear errors and possibly trigger any cascade recompiles
	DMCache.add_file(source_file, result)

	var err: Error = ResourceSaver.save(resource, "%s.%s" % [save_path, _get_save_extension()])

	compiled_resource.emit(resource)

	# Recompile any dependencies
	var dependent_paths: PackedStringArray = DMCache.get_dependent_paths_for_reimport(source_file)
	for path: String in dependent_paths:
		append_import_external_resource(path)

	return err
